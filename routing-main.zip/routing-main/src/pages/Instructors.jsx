import React from 'react';

const Instructors = () => {
  return (
    <div>Instructors</div>
  );
};

export default Instructors;